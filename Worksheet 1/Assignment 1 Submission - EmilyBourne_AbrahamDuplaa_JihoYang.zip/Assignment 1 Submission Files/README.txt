This folder contains all the submission files and report for Assignment 1.

Please note the submission file for section 4.4.1 (pair of matching code snippets with Intel and AT&T styles) is not included, but instead included in the report. Since it required only code snippets we found it more suitable that we write it in the report.

The group members for this work are:

Emily Bourne
Abraham Duplaa
Jiho Yang


